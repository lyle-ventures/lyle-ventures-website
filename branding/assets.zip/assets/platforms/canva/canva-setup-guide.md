# Canva Brand Kit Setup Guide — Lyle Ventures

## Colors

Add these colors to the Canva Brand Kit in this order:

| Name | Hex | Role |
|------|-----|------|
| Indigo | `#6366f1` | Primary accent |
| Near Black | `#111827` | Primary text (on light backgrounds) |
| White | `#ffffff` | Primary background |
| Muted | `#9ca3af` | Metadata text |
| Pure Dark | `#08080c` | Internal/Universe dashboard only |
| Dark Card | `#111118` | Internal/Universe secondary only |

### Sector Colors (add as secondary palette)

| Name | Hex |
|------|-----|
| AI Mechanicals | `#00D4FF` |
| Scarce Crypto | `#CC44FF` |
| Defense Tech | `#FF3366` |
| Health Tech | `#00C46A` |
| Community Experience | `#FFB800` |

## Fonts

| Canva Role | Font | Weight | Size |
|-----------|------|--------|------|
| Heading | Inter | SemiBold (600) | 36pt |
| Subheading | Inter | Medium (500) | 20pt |
| Body | Inter | Regular (400) | 14pt |

Inter is available natively in Canva — no upload needed.

## Logos

Upload these files to Brand Kit logos:

1. **Primary wordmark:** `assets/logos/png/wordmark/lyle-ventures-standard-8x.png`
   - Name in Canva: "Lyle Ventures Wordmark"
2. **Square mark:** `assets/logos/png/thumbnail/square/lv-linkedin-logo-indigo-outline-8x.png`
   - Name in Canva: "LV Square Mark"
3. **Favicon/icon:** `assets/logos/png/thumbnail/square/lv-icon-indigo-512.png`
   - Name in Canva: "LV Icon"

## Templates

When creating Canva templates:
- Default background: `#ffffff` (White) — matches public brand
- Default text color: `#111827` (Near Black)
- Accent color: `#6366f1` (Indigo)
- Use Inter at the weights specified above
- Maintain consistent margins (minimum 40px on all sides at 1080p)

## Photography Treatment

- Keep photos natural — avoid heavy filters or overlays
- No bright, saturated stock photos — keep the mood understated
- If text overlays a photo, use a subtle white or nearBlack overlay for contrast
