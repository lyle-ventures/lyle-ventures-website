# Email Signature Setup Guide

*Source file:* `lv-email-signature.html`

---

## Design Notes

The email signature uses a **light theme** — white background with system grays. This is consistent with the public brand (lyle.vc is `bg-white`). Email clients universally render on white backgrounds, so system grays are used instead of the brand's nearBlack for maximum compatibility.

Only the indigo accent (`#6366f1`) must match the brand palette. The gray values (`#1a1a1a`, `#555555`, `#888888`) are email-standard system colors defined in `lib/tokens.mjs` under the `EMAIL` export.

**Font stack:** `-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif` — system fonts for universal rendering. Inter is not available in email clients.

---

## Setup: Gmail

1. Open `lv-email-signature.html` in Chrome
2. Select everything between the two comment markers (`<!-- EMAIL SIGNATURE -->`)
3. Copy (Cmd+C)
4. Go to Gmail → Settings (gear) → See all settings → General
5. Scroll to **Signature** section
6. Click the signature box and paste (Cmd+V)
7. Scroll down and click **Save Changes**

**Tip:** Gmail may strip some formatting on paste. If the signature looks wrong, paste into a Gmail compose window first, verify it renders correctly, then copy from there into the signature settings.

---

## Setup: Apple Mail

1. Open `lv-email-signature.html` in Safari
2. Select the signature content between the comment markers
3. Copy (Cmd+C)
4. Open Mail → Settings → Signatures
5. Select the email account
6. Click **+** to add a new signature
7. Click in the preview pane and paste (Cmd+V)
8. Uncheck "Always match my default message font" if prompted

---

## Setup: Outlook (Desktop)

1. Open `lv-email-signature.html` in Edge or Chrome
2. Select and copy the signature content
3. Open Outlook → Settings → Mail → Compose and reply
4. Under **Email signature**, paste into the editor
5. Set as default for new messages and replies
6. Click **Save**

---

## Setup: Outlook (Web / Microsoft 365)

1. Open `lv-email-signature.html` in the browser
2. Select and copy the signature content
3. Go to Outlook web → Settings (gear) → Mail → Compose and reply
4. Under **Email signature**, click in the editor and paste
5. Set as default signature
6. Click **Save**

---

## What's in the Signature

| Element | Value |
|---------|-------|
| Name | Ethan Lyle |
| Title | Managing Partner & Chief Investment Officer |
| Brand | Lyle.Ventures (indigo) |
| Phone | 404-219-9546 |
| Email | ethan@lyle-ventures.xyz |
| Web | lyle-ventures.xyz |

---

## Color Reference

| Role | Hex | Token |
|------|-----|-------|
| Body text | `#1a1a1a` | `EMAIL.textPrimary` |
| Title / secondary | `#555555` | `EMAIL.textSecondary` |
| Labels (M: / E: / W:) | `#888888` | `EMAIL.textLabel` |
| Indigo accent | `#6366f1` | `EMAIL.accent` = `C.indigo` |
| Background | `#ffffff` | `EMAIL.bg` |

---

## Rules

- Do not change the indigo accent color — it must match `#6366f1`
- Do not add images, logos, or social icons — clean text only
- Do not add legal disclaimers or confidentiality notices
- Keep the system font stack — do not substitute custom fonts
- The signature HTML is the source of truth; don't edit the pasted version in email settings
